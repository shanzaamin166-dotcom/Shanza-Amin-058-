import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
import os

# 1. Load English Dataset (CSV)
csv_file = "universitystudents_complaints.csv"
texts = []
labels = []

# --- Part A: Load English Data from CSV ---
if os.path.exists(csv_file):
    df = pd.read_csv(csv_file)
    
    # Priority Logic based on English Categories
    high_priority_genres = ['Health and Well-being Support', 'Housing and Transportation', 'Food and Cantines', 'Financial Support']
    
    def assign_priority(genre):
        return 'High' if genre in high_priority_genres else 'Low'

    df['Priority'] = df['Genre'].apply(assign_priority)
    
    # Add CSV data to our lists
    texts.extend(df['Reports'].tolist())
    labels.extend(df['Priority'].tolist())

# --- Part B: Add Roman Urdu / Desi Data (Manual Injection) ---
# Hum AI ko kuch common Urdu words sikha rahe hain
roman_urdu_data = [
    # High Priority (Urdu)
    ("Mujhy high fever hai aur koi doctor nahi", "High"),
    ("Hostel mein aag lag gayi hai", "High"),
    ("Larko ki larai ho gayi hai corridor mein", "High"),
    ("Mera laptop chori ho gaya library se", "High"),
    ("Tabiyat bohat khraab hai, ambulance chahiye", "High"),
    ("Electric wire se current lag raha hai", "High"),
    ("Khana kha kar food poisoning ho gayi", "High"),
    ("Washroom mein pani leak ho raha hai current aa rha h", "High"),
    ("Senior students tang kar rahe hain ragging", "High"),
    
    # Low Priority (Urdu)
    ("Wifi slow chal raha hai", "Low"),
    ("Classroom ganda hai safai karwani hai", "Low"),
    ("Assignment ki deadline extend kar dein", "Low"),
    ("Library kab khule gi?", "Low"),
    ("Date sheet kab aayegi?", "Low"),
    ("Paani ka cooler khali hai", "Low"),
    ("Chair toot gayi hai", "Low"),
    ("Fees kahan jama karwani hai?", "Low")
]

# Add Urdu data to the main lists
for text, label in roman_urdu_data:
    texts.append(text)
    labels.append(label)

# 2. Build and Train Model
# CountVectorizer ab English aur Urdu dono words ko numbers mein badal dega
model = make_pipeline(CountVectorizer(), MultinomialNB())
model.fit(texts, labels)

print(f"Model trained on {len(texts)} complaints (English + Roman Urdu).")

# 3. Prediction Function
def predict_priority(complaint_text):
    prediction = model.predict([complaint_text])
    return prediction[0]