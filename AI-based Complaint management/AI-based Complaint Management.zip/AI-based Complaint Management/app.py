from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
import re
from ai_model import predict_priority  # <--- IMPORT THE AI MODEL

app = Flask(__name__)
app.secret_key = "your_secret_key"

# --- Database setup ---
def init_db():
    conn = sqlite3.connect("complaints.db")
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS complaints (
                        name TEXT,
                        reg_no TEXT,
                        department TEXT,
                        complaint TEXT,
                        date TEXT,
                        priority TEXT
                    )''')
    conn.commit()
    conn.close()

init_db() # Run once on startup

# --- Home Page ---
@app.route('/')
def index():
    return render_template('index.html', current_year=2025)

# --- Student Login ---
@app.route('/student_login', methods=['GET', 'POST'])
def student_login():
    if request.method == 'POST':
        reg_no = request.form['reg_no']
        password = request.form['password'] # In a real app, check DB for password

        # Validate reg_no format
        pattern = r'^(FA|SP)\d{2}-(BCS|BSE|BEN|BSM)-\d{3}$'
        if not re.match(pattern, reg_no):
             # Ensure your HTML displays this error variable if passed
            return render_template('student_login.html', error="Invalid Format")

        session['reg_no'] = reg_no
        return redirect(url_for('student_dashboard'))
    return render_template('student_login.html')

# --- Student Dashboard (Submitting Complaint) ---
@app.route('/student_dashboard', methods=['GET', 'POST'])
def student_dashboard():
    reg_no = session.get('reg_no')
    if not reg_no:
        return redirect(url_for('student_login'))

    if request.method == 'POST':
        name = request.form['name']
        department = request.form['department']
        complaint_text = request.form['complaint']

        # --- AI MAGIC HAPPENS HERE ---
        # We send the text to our model, it returns 'High' or 'Low'
        ai_priority = predict_priority(complaint_text) 

        conn = sqlite3.connect("complaints.db")
        cursor = conn.cursor()
        # We insert the AI-detected priority instead of 'Normal'
        cursor.execute("INSERT INTO complaints (name, reg_no, department, complaint, date, priority) VALUES (?, ?, ?, ?, datetime('now', 'localtime'), ?)",
                       (name, reg_no, department, complaint_text, ai_priority))
        conn.commit()
        conn.close()
        
        # Optional: Show a success message or redirect
        return render_template('student_dashboard.html', reg_no=reg_no, success="Complaint Submitted!")

    return render_template('student_dashboard.html', reg_no=reg_no)

# --- Admin Login ---
@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Hardcoded Admin Credentials for the project
        if username == "admin" and password == "admin123":
            session['admin_logged_in'] = True
            return redirect(url_for('admin_dashboard'))
        else:
            return render_template('admin_login.html', error="Invalid Credentials")
            
    return render_template('admin_login.html')

# --- Admin Dashboard (Viewing Complaints) ---
@app.route('/admin_dashboard')
def admin_dashboard():
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    
    conn = sqlite3.connect("complaints.db")
    cursor = conn.cursor()
    # Fetch all complaints, newest first
    cursor.execute("SELECT * FROM complaints ORDER BY date DESC")
    data = cursor.fetchall()
    conn.close()
    
    return render_template('admin_dashboard.html', complaints=data)

# --- Logout ---
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)