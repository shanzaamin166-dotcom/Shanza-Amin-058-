Project: AI-Based Student Complaint System

Note: The attached demo video has no audio. Please read this summary to understand the project workflow.

1. Technical Overview:

Algorithm: Multinomial Naive Bayes (Supervised Machine Learning).

Dataset: The model is trained on 1,022 real student complaints (Source: Kaggle).

Goal: The AI automatically detects the urgency of a complaint and assigns a priority (High, Medium, or Low).

2. Key Features:

Multi-lingual Support: The system understands both English and Roman Urdu (e.g., "Hostel mein pani nahi aa raha").

Real-time Prediction: As soon as a student submits, the AI predicts the priority instantly.

3. Workflow (Shown in Video):

Student: Logs in and submits a complaint (e.g., a medical emergency or facility issue).

AI Model: Processes the text in the background.

Admin: Logs in to the Dashboard and sees the complaint marked with the predicted priority (Red for High, Green for Low).

Admin Credentials:

Username: admin

Password: admin123